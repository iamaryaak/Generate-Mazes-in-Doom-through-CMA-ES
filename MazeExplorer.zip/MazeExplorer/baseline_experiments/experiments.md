# Baseline experiments

1. python experiment.py --number_maps 1  --seed 42 --algorithm ppo
1. python experiment.py --number_maps 10 --seed 42 --algorithm ppo
1. python experiment.py --number_maps 100 --seed 42 --algorithm ppo
1. python experiment.py --number_maps 1  --seed 42 --algorithm ppo --random_spawn 1
1. python experiment.py --number_maps 10 --seed 42 --algorithm ppo --random_spawn 1
1. python experiment.py --number_maps 100 --seed 42 --algorithm ppo --random_spawn 1
1. python experiment.py --number_maps = 1  --seed 42 --algorithm a2c
1. python experiment.py --number_maps = 10 --seed 42 --algorithm a2c
1. python experiment.py --number_maps = 100 --seed 42 --algorithm a2c
