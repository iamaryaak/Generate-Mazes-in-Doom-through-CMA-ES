from mazeexplorer import MazeExplorer

env_train = MazeExplorer(number_maps=1, keys=9, size=(11, 11), random_spawn=False, random_textures=False, seed=42)
