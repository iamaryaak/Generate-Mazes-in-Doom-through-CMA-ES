# ACC
ACC is an ACS script compiler for use with ZDoom and Hexen.
http://zdoom.org/wiki/ACC

## Usage
	Usage: ACC [options] source[.acs] [object[.o]]
	-i [path]  Add include path to find include files
	-d[file]   Output debugging information
	-h         Create pcode compatible with Hexen and old ZDooms
	-hh        Like -h, but use of new features is only a warning
