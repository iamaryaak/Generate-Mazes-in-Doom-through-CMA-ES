# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License

name = "mazeexplorer"

from .mazeexplorer import MazeExplorer
from .vizdoom_gym import VizDoom
