#!/usr/bin/env bash
pytest tests -W ignore